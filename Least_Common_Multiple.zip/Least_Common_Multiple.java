import java.util.Scanner;
import java.lang.Math;

class Solution {

	public static int least_common_multiple(int x, int y) {
		int lcm = -1;

		/* ======= Your Code Here ======= */

		/* ======= Your Code Ends ======= */

		return lcm;
	}

/* ======= Do Not Touch ======= */

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		// gather input
    	String x_string = scanner.nextLine();
    	String y_string = scanner.nextLine();

    	// convert string to int
    	int x = Integer.parseInt(x_string);
    	int y = Integer.parseInt(y_string);
    
    	// Function Call
    	System.out.println(least_common_multiple(x, y));

    	scanner.close();

	}
}