class Solution(object):

	def least_common_multiple(self, x: int, y: int) -> int:
		lcm = 1

		# ======= Your Code Here =======

		# ======= Your Code Ends ======= 

		return lcm


# ======= Do Not Touch =======
def main():
	s = Solution()
	x = int(input(""))
	y = int(input(""))
	print(s.least_common_multiple(x ,y))

if __name__ == '__main__':
	main()